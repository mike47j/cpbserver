Tournament Software

This software is a web server which uses Javascript enabled web browsers to do the work. So multiple computers, laptops, tablets or smart phones can be used to enter data or display the leader board and results.

So far it only does score sheets, and running slips for rounds which are in dozens and half dozens, i.e. not Worcester round.

Since everything is calculated from the round information you can have a handicap competition which includes rounds for which there is no published handicap table.

Using the running slips with every arrow recorded I reckon it takes about 15 seconds to enter and check the adding up of a dozen arrows for one archer. So for up to 60 archers then probably 1 laptop can be used to enter all the data for a dozen in about 15 minutes. For more archers it would be best to have more data entry laptops which would need to be connected into a network. Hopefully its simple to enter data so the runners collecting the slips can also enter the data.

Installation

Copy all the files to a directory and run cpbserver.exe. If the directory is on a usb memory stick then it can be moved if the computer fails. Probably best if the server is run on a laptop with a good battery. Because it open a couple of TCP/IP ports, Windows Firewall and some anti-virus software may block access, hopefully it will ask before it does this so you can allow access.
When the program starts a window should open and display something like:
Server address 192.168.1.64 ports 80, 4023

There is a small configuration file cpbserver.cfg which has a single line and may look like:
?Path=&Result=80&Update=4023&Timeout=20 

Timeout is the time delay with no data being entered, before a backup is done.
Update is the secure port for data entry, change this to stop anyone nearby entering data.
Result is the port for the leader board and results information. 80 is standard for web servers and should not need to be changed, unless you are just testing and already running a web server on the PC. Path is only needed if most of the files are in a different directory to the exe and cfg files. Such as when testing changes to the server software. 
?Path=E:\Archery\Server\CPBserver\&Result=83&Update=4023&Timeout=30 

Leader Board

With a wifi connection to the network, anyone can get the leader board by connecting to the network and  entering the server address eg: http://192.168.1.64. For a scrolling large screen display then  http://192.168.1.64/scroll

Set Up A Competition

Open a web browser and use the ip address from the server window and the second port number
e.g. http://192.168.1.64:4023/setup
This will display the tournament set up screen.

To get started enter the details in the boxes, and click submit. Best to have 1 or 2  more targets than needed. 

Medals are given for shooting the round for your age (or longer).  For Juniors as Gold, Silver and Bronze, Seniors only Gold for 1 to 3 archers completing the round (DNS or retired not counting), Gold and Silver for 4 to 6, Gold, Silver and Bronze for 7 or more. Juniors are in the same result list as seniors and have a J after their name, which means the medals may not be the top 3 places in the list.

Best Archer and Junior championship points calculated as scores are entered, by dividing the score by the Bowmen classification score for each age group and round and multiplying by 2000. Rounds without a bowmen classification score are calculated from the handicap for the bowmen classification. 

Score entry system, either enter every arrow value, the dozen totals, or just totals.

Next �Clear Everything� and �Add Archers�, don't care about mixing rounds on one target yet.

Then �Re-allocate Targets� to un-mix the rounds and get all longbows together etc. Just click in a list to move an entry from one side to the other or leave a target empty.

After that http://192.168.1.64:4023/index is the data entry start page.

Hopefully everything should be easy to use, I'll write more documentation later.

Files

cpbserver.exe	main exe server file written in C#
cpbserver.cfg	configuration file
allocate.txt	javascript files
byname.txt
index.txt
movearcher.txt
newarcher.txt
printrun.txt
printscore.txt
results.txt
rounds.txt
scoreentry.txt
scoresheet.txt
setup.txt
updateentry.txt




